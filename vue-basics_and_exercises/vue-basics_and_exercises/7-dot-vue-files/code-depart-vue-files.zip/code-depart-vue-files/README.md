# Installation :

Tapez les commandes suivantes :
La commande suivante installera les dépendances requises pour faire fonctionner les fichiers .vue
```bash
cd /chemin/jusqu'a/application
npm install
```

Cette comande compilera l'application et créera un dossier 'dist' ou 'vit' l'application
```bash
npm run build # compilation de l'application
```
Cette commande démarrera un serveur, les fichiers .vue modifiés seront automatiquement pris en compte et le navigateur rechargera automatiquement la page.
```bash
npm run dev # démarrage du serveur
```

