export default Vue.component('FooterTemplate', {
    template: `
        <div class="footer">
            <footer>
                <a href="https://3wa.fr">3WAcademy</a>
            </footer>
        </div>
   `,
});
