Les différentes pages ont été conçus pour être interactives. Sur moodle, l'interactivité ne fonctionne pas, il faut qu'ils exécutent le code directement sur leur ordinateur pour ça

Chaque page aborde une notion différente sur Vue.js et est accompagnée d'un petit exercice en rapport.

La version de vue.js utilisé est Vue2.6, Vue3 étant toujours en beta à l'heure de l'écriture de ces lignes. De plus tout ce qui est codé en Vue2 devrait fonctionner avec Vue3.

Concernant 7-dot-vue-files sur l'extension de fichiers .vue, la configuration de webpack a été faite à la main, juste pour la démonstration, mais il faudra plutôt leur dire de se diriger vers `@vue/cli` pour leurs projets.

L'exercice final est un carnet d'adresse CRUD qui utilise le localStorage pour stocker les données, la page ne se rafraîchit jamais.
